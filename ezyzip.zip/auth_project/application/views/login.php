<html>
<head>
	<title>Vendor Login</title>
	<link rel="stylesheet" href="<?php echo base_url().'assets/css/bootstrap.css'?>">
	<link rel="stylesheet" href="<?php echo base_url().'assets/css/login.css'?>">
</head>
<body>
	<form class="form-signin" action="<?php echo base_url().'index.php/Auth/login'?>" name="loginForm" id="loginForm" method="post">

		<?php 
			$msg = $this->session->flashdata('msg');
			if($msg!=""){
				?>
				<div class='alert alert-danger'>
					<?php echo $msg?>
				</div>
				<?php
			}
		?>

	    <h1 class="h3 mb-3 fw-bold text-center">Vendor Login</h1>

	    <div class="form-group">
	    	<label for="floatingInput">Phone Number</label>
	      	<input type="text" name="phone_number" id="phone_number" value="<?php echo set_value('phone_number')?>" class="form-control <?php echo (form_error('phone_number') !="") ? "is-invalid":'';?>"  placeholder="6262179962">
	      	<p class="invalid-feedback"><?php echo strip_tags(form_error('phone_number'));?></p>
	    </div>

	    <div class="form-group">
	    	<label for="floatingPassword">Password</label>
	      	<input type="password" name="password" id="password" value="<?php echo set_value('password')?>" class="form-control <?php echo (form_error('password') !="") ? "is-invalid":'';?>" placeholder="Password">
	      	<p class="invalid-feedback"><?php echo strip_tags(form_error('password'));?></p>
	    </div>

	    <button class="w-100 btn btn-lg btn-primary" type="submit">Sign in</button>
  </form>
</body>
</html>





<html>
<head>
	<title>Vendor Registration</title>
	
	<link rel="stylesheet" href="<?php echo base_url().'assets/css/bootstrap.css'?>">
	<link rel="stylesheet" href="<?php echo base_url().'assets/css/style.css'?>">
</head>
<body>
	<div class="container">
		<?php 
			$msg = $this->session->flashdata('msg');
			if($msg!=""){
				echo "<div class='alert alert-success'>$msg</div>";
			}
		?>
		<div class="col-md-6">
			<div class="card mt-4">
  				<div class="card-header">
    				<h5>Vendor Registration</h5>
  				</div>
  				<form action="<?php echo base_url().'index.php/Auth/register'?>" name="registerForm" id="registerForm" method="post">
	  				<div class="card-body register">
	    			<p class="card-text">Fill your details</p>
	    				<div class="form-group">
	    					<label for="name">Name</label>
	    					<input type="text" name="name" id="name" value="<?php echo set_value('name')?>" class="form-control <?php echo (form_error('name') !="") ? "is-invalid":'';?>" placeholder="Name">
	    					<p class="invalid-feedback"><?php echo strip_tags(form_error('name'));?></p>
	    				</div>

	    				<div class="form-group">
	    					<label for="name">Email</label>
	    					<input type="text" name="email" id="email" value="<?php echo set_value('email')?>" class="form-control <?php echo (form_error('email') !="") ? "is-invalid":'';?>" placeholder="Email">
	    					<p class="invalid-feedback"><?php echo strip_tags(form_error('email'));?></p>
	    				</div>

	    				<div class="form-group">
	    					<label for="name">Phone number</label>
	    					<input type="text" name="phone_number" id="phone_number" value="<?php echo set_value('phone_number')?>" class="form-control <?php echo (form_error('phone_number') !="") ? "is-invalid":'';?>" placeholder="Phone number">
	    					<p class="invalid-feedback"><?php echo strip_tags(form_error('phone_number'));?></p>
	    				</div>

	    				<!-- <div class="form-group">
	    					<label for="name">Password</label>
	    					<input type="password" name="password" id="password" value="<?php echo set_value('password')?>" class="form-control <?php echo (form_error('password') !="") ? "is-invalid":'';?>" placeholder="Password"
	    					>
	    					<p class="invalid-feedback"><?php echo strip_tags(form_error('password'));?></p>
	    				</div> -->

	    				<div class="form-group">
			    				 	<label for="name"><h5>Gender</h5></label>
			    				 	<input list="gen" name="gender" id="gender" value="<?php echo set_value('gender')?>" class="form-control <?php echo (form_error('gender') != "") ? 'is-invalid' : '';?>" placeholder="select">
			    				 	<p class="invalid-feedback"><?php echo strip_tags(form_error('gender'));?></p>
			    				 	<datalist id="gen">
    									<option value="Male">
    									<option value="Female">
    									<option value="Others">
  									</datalist>
  						</div>

	    				<div class="form-group">
	    					<label for="name">Provided Item Type</label>
	    					<input type="text" name="item" id="item" value="<?php echo set_value('item')?>" class="form-control <?php echo (form_error('item') !="") ? "is-invalid":'';?>" placeholder="Eg:Food,Stationary">
	    					<p class="invalid-feedback"><?php echo strip_tags(form_error('item'));?></p>
	    				</div>

	    				<div class="form-group">
	    					<button class="btn btn-block btn-primary mt-2">REGISTER</button>
	    				</div>
	  				</div>
  				</form>
			</div>
		</div>
	</div>
</body>
</html>

<html>
<head>
	<title>Budget Registration</title>
	
	<link rel="stylesheet" href="<?php echo base_url().'assets/css/bootstrap.css'?>">
	<link rel="stylesheet" href="<?php echo base_url().'assets/css/style.css'?>">
</head>
<body>
	<div class="container">
		<?php 
			$msg = $this->session->flashdata('msg');
			if($msg!=""){
				echo "<div class='alert alert-success'>$msg</div>";
			}
		?>
		<div class="col-md-6">
			<div class="card mt-4">
  				<div class="card-header">
    				<h5>Budget Registration</h5>
  				</div>
  				<form action="<?php echo base_url().'index.php/Auth/budgetRegister'?>" name="registerForm" id="registerForm" method="post">
	  				<div class="card-body register">
	    			<p class="card-text">Fill the details</p>
	    				<div class="form-group">
	    					<label for="name">Uploaded By</label>
	    					<input type="text" name="uploaded_by" id="uploaded_by" value="<?php echo set_value('uploaded_by')?>" class="form-control <?php echo (form_error('uploaded_by') !="") ? "is-invalid":'';?>" placeholder="Enter GST no. of the Vendor or Guest">
	    					<p class="invalid-feedback"><?php echo strip_tags(form_error('uploaded_by'));?></p>
	    				</div>

	    				<div class="form-group">
			    				 	<label for="name"><h5>Fund Type</h5></label>
			    				 	<input list="fun" name="fund_type" id="fund_type" value="<?php echo set_value('fund_type')?>" class="form-control <?php echo (form_error('fund_type') != "") ? 'is-invalid' : '';?>" placeholder="select">
			    				 	<p class="invalid-feedback"><?php echo strip_tags(form_error('fund_type'));?></p>
			    				 	<datalist id="fun">
    									<option value="Plan">
    									<option value="Non-Plan">
    									<option value="Project">
  									</datalist>
  						</div>


	    				<div class="form-group">
			    				 	<label for="name"><h5>Head</h5></label>
			    				 	<input list="hdd" name="head" id="head" value="<?php echo set_value('head')?>" class="form-control <?php echo (form_error('head') != "") ? 'is-invalid' : '';?>" placeholder="select">
			    				 	<p class="invalid-feedback"><?php echo strip_tags(form_error('head'));?></p>
			    				 	<datalist id="hdd">
    									<option value="Repair">
    									<option value="Salary">
    									<option value="Phone">
    									<option value="Telecom">
    									<option value="Tour">
    									<option value="Medical">
    									<option value="Other">
  									</datalist>
  						</div>

	    				<div class="form-group">
	    					<label for="name">Remark</label>
	    					<input type="text" name="remark" id="remark" value="<?php echo set_value('remark')?>" class="form-control <?php echo (form_error('remark') !="") ? "is-invalid":'';?>" placeholder="Remark">
	    					<p class="invalid-feedback"><?php echo strip_tags(form_error('remark'));?></p>
	    				</div>

	    				<div class="form-group">
	    					<label for="name">Purpose For Fund</label>
	    					<input type="text" name="purpose_for_fund" id="purpose_for_fund" value="<?php echo set_value('purpose_for_fund')?>" class="form-control <?php echo (form_error('purpose_for_fund') !="") ? "is-invalid":'';?>" placeholder="Purpose For Fund">
	    					<p class="invalid-feedback"><?php echo strip_tags(form_error('purpose_for_fund'));?></p>
	    				</div>

	    				

	    				<div class="form-group">
	    					<button class="btn btn-block btn-primary mt-2">REGISTER</button>
	    				</div>
	  				</div>
  				</form>
			</div>
		</div>
	</div>
</body>
</html>
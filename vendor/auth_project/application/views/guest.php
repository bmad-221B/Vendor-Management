
<html>
<head>
	<title>Guest Registration</title>
	
	<link rel="stylesheet" href="<?php echo base_url().'assets/css/bootstrap.css'?>">
	<link rel="stylesheet" href="<?php echo base_url().'assets/css/style.css'?>">
</head>
<body>
	<div class="container">
		<?php 
			$msg = $this->session->flashdata('msg');
			if($msg!=""){
				echo "<div class='alert alert-success'>$msg</div>";
			}
		?>
		<div class="col-md-6">
			<div class="card mt-4">
  				<div class="card-header">
    				<h5>Guest Registration</h5>
  				</div>
  				<form action="<?php echo base_url().'index.php/Auth/guestRegister'?>" name="registerForm" id="registerForm" method="post">
	  				<div class="card-body register">
	    			<p class="card-text">Fill your details</p>
	    				<div class="form-group">
	    					<label for="name">Name</label>
	    					<input type="text" name="name" id="name" value="<?php echo set_value('name')?>" class="form-control <?php echo (form_error('name') !="") ? "is-invalid":'';?>" placeholder="Name">
	    					<p class="invalid-feedback"><?php echo strip_tags(form_error('name'));?></p>
	    				</div>

	    				<div class="form-group">
	    					<label for="name">Email</label>
	    					<input type="text" name="email" id="email" value="<?php echo set_value('email')?>" class="form-control <?php echo (form_error('email') !="") ? "is-invalid":'';?>" placeholder="Email">
	    					<p class="invalid-feedback"><?php echo strip_tags(form_error('email'));?></p>
	    				</div>

	    				<div class="form-group">
	    					<label for="name">Phone number</label>
	    					<input type="text" name="phone_number" id="phone_number" value="<?php echo set_value('phone_number')?>" class="form-control <?php echo (form_error('phone_number') !="") ? "is-invalid":'';?>" placeholder="Phone number">
	    					<p class="invalid-feedback"><?php echo strip_tags(form_error('phone_number'));?></p>
	    				</div>

	    				<div class="form-group">
	    					<label for="name">Country</label>
	    					<input type="text" name="country" id="country" value="<?php echo set_value('country')?>" class="form-control <?php echo (form_error('country') !="") ? "is-invalid":'';?>" placeholder="Eg:India,USA,UK">
	    					<p class="invalid-feedback"><?php echo strip_tags(form_error('country'));?></p>
	    				</div>

	    				<div class="form-group">
	    					<label for="name">State</label>
	    					<input type="text" name="state" id="state" value="<?php echo set_value('state')?>" class="form-control <?php echo (form_error('state') !="") ? "is-invalid":'';?>" placeholder="Eg:Chhattisgarh,Punjab">
	    					<p class="invalid-feedback"><?php echo strip_tags(form_error('state'));?></p>
	    				</div>

	    				<div class="form-group">
	    					<label for="name">District</label>
	    					<input type="text" name="district" id="district" value="<?php echo set_value('district')?>" class="form-control <?php echo (form_error('district') !="") ? "is-invalid":'';?>" placeholder="Eg:Bilaspur,Leh,Jaisalmer">
	    					<p class="invalid-feedback"><?php echo strip_tags(form_error('district'));?></p>
	    				</div>

	    				<div class="form-group">
	    					<label for="name">Pin Code</label>
	    					<input type="text" name="pin_code" id="pin_code" value="<?php echo set_value('pin_code')?>" class="form-control <?php echo (form_error('pin_code') !="") ? "is-invalid":'';?>" placeholder="Eg:495222">
	    					<p class="invalid-feedback"><?php echo strip_tags(form_error('pin_code'));?></p>
	    				</div>

	    				<div class="form-group">
	    					<button class="btn btn-block btn-primary mt-2">REGISTER</button>
	    				</div>
	  				</div>
  				</form>
			</div>
		</div>
	</div>
</body>
</html>
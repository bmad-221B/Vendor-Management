
<html>
<head>
	<title>Transaction Registration</title>
	
	<link rel="stylesheet" href="<?php echo base_url().'assets/css/bootstrap.css'?>">
	<link rel="stylesheet" href="<?php echo base_url().'assets/css/style.css'?>">
</head>
<body>
	<div class="container">
		<?php 
			$msg = $this->session->flashdata('msg');
			if($msg!=""){
				echo "<div class='alert alert-success'>$msg</div>";
			}
		?>
		<div class="col-md-6">
			<div class="card mt-4">
  				<div class="card-header">
    				<h5>Transaction Registration</h5>
  				</div>
  				<form action="<?php echo base_url().'index.php/Auth/transactionRegister'?>" name="registerForm" id="registerForm" method="post">
	  				<div class="card-body register">
	    			<p class="card-text">Fill the details</p>
	    				<div class="form-group">
	    					<label for="name">Uploaded By</label>
	    					<input type="text" name="uploaded_by" id="uploaded_by" value="<?php echo set_value('uploaded_by')?>" class="form-control <?php echo (form_error('uploaded_by') !="") ? "is-invalid":'';?>" placeholder="Enter GST no. of the Vendor or Guest">
	    					<p class="invalid-feedback"><?php echo strip_tags(form_error('uploaded_by'));?></p>
	    				</div>

	    				<div class="form-group">
	    					<label for="name">Date of Payment</label>
	    					<input type="date" name="date_of_payment" id="date_of_payment" value="<?php echo set_value('date_of_payment')?>" class="form-control <?php echo (form_error('date_of_payment') !="") ? "is-invalid":'';?>" placeholder="DD/MM/YYYY">
	    					<p class="invalid-feedback"><?php echo strip_tags(form_error('date_of_payment'));?></p>
	    				</div>


	    				<div class="form-group">
	    					<label for="name">Gross Amount</label>
	    					<input type="number" step="0.0001" name="gross_amount" id="gross_amount" value="<?php echo set_value('gross_amount')?>" class="form-control <?php echo (form_error('gross_amount') !="") ? "is-invalid":'';?>" placeholder="1000.00">
	    					<p class="invalid-feedback"><?php echo strip_tags(form_error('gross_amount'));?></p>
	    				</div>

	    				<div class="form-group">
	    					<label for="name">Taxable Amount</label>
	    					<input type="number" step="0.0001" name="taxable_amount" id="taxable_amount" value="<?php echo set_value('taxable_amount')?>" class="form-control <?php echo (form_error('taxable_amount') !="") ? "is-invalid":'';?>" placeholder="1000.00">
	    					<p class="invalid-feedback"><?php echo strip_tags(form_error('taxable_amount'));?></p>
	    				</div>

	    				<div class="form-group">
	    					<label for="name">GST Taxable Amount</label>
	    					<input type="number" step="0.0001" name="gst_taxable_amount" id="gst_taxable_amount" value="<?php echo set_value('gst_taxable_amount')?>" class="form-control <?php echo (form_error('gst_taxable_amount') !="") ? "is-invalid":'';?>" placeholder="1000.00">
	    					<p class="invalid-feedback"><?php echo strip_tags(form_error('gst_taxable_amount'));?></p>
	    				</div>

	    				

	    				<div class="form-group">
	    					<button class="btn btn-block btn-primary mt-2">REGISTER</button>
	    				</div>
	  				</div>
  				</form>
			</div>
		</div>
	</div>
</body>
</html>
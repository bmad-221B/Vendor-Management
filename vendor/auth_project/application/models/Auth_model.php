<?php

/**
 * 
 */
class Auth_model extends CI_Model
{
	//saves on database
	public function create($formArray)
	{
		$this->db->insert('users',$formArray);
	}

	public function checkUser($phone_number)
	{
		$this->db->where('phone_number',$phone_number);
		$row = $this->db->get('users')->row_array();
		return $row;
	}

	public function guestCreate($formArray)
	{
		$this->db->insert('guest',$formArray);	
	}

	public function transactionCreate($formArray)
	{
		$this->db->insert('transaction',$formArray);	
	}

	public function budgetCreate($formArray)
	{
		$this->db->insert('budget',$formArray);	
	}
}

?>
<?php

/**
 * 
 */
class Auth extends CI_Controller
{
	
	public function register()
	{
		$this->load->library('form_validation');

		$this->form_validation->set_message('is_unique','Phone number already exits,pls enter another!');

		$this->form_validation->set_rules('name','Name','required');
		$this->form_validation->set_rules('email','Email','required|valid_email');
		$this->form_validation->set_rules('phone_number','Phone number','required|is_unique[users.phone_number]');
		// $this->form_validation->set_rules('password','Password','required');
		$this->form_validation->set_rules('gender','Gender','required');
		$this->form_validation->set_rules('item','Provided Item Type','required');

		if($this->form_validation->run() == false)
		{
			$this->load->view('register');
		}
		else
		{
			$this->load->model('Auth_model');
			$formArray=array();
			$formArray['name']=$this->input->post('name');
			$formArray['email']=$this->input->post('email');
			$formArray['phone_number']=$this->input->post('phone_number');
			// $formArray['password']=md5($this->input->post('password'));
			$formArray['gender']=$this->input->post('gender');
			$formArray['item']=$this->input->post('item');
			$this->Auth_model->create($formArray);

			$this->session->set_flashdata('msg','Accout Created Successfully');
			redirect(base_url().'index.php/Auth/register');
		}
	}
	//public guest function
	public function guestRegister()
	{
		$this->load->library('form_validation');

		$this->form_validation->set_message('is_unique','Phone number already exits,pls enter another!');

		$this->form_validation->set_rules('name','Name','required');//Guest Name
		$this->form_validation->set_rules('email','Email','required|valid_email');//This and below
		$this->form_validation->set_rules('phone_number','Phone number','required|is_unique[guest.phone_number]');//guest contact details
		$this->form_validation->set_rules('country','Country','required');
		$this->form_validation->set_rules('state','State','required');
		$this->form_validation->set_rules('district','District','required');
		$this->form_validation->set_rules('pin_code','Pin code','required');
		// $this->form_validation->set_rules('item','Provided Item Type','required');

		if($this->form_validation->run() == false)
		{
			$this->load->view('guest');
		}
		else
		{
			$this->load->model('Auth_model');
			$formArray=array();
			$formArray['name']=$this->input->post('name');
			$formArray['email']=$this->input->post('email');
			$formArray['phone_number']=$this->input->post('phone_number');
			$formArray['country']=($this->input->post('country'));
			$formArray['state']=($this->input->post('state'));
			$formArray['district']=($this->input->post('district'));
			$formArray['pin_code']=$this->input->post('pin_code');
			// $formArray['item']=$this->input->post('item');
			$this->Auth_model->guestCreate($formArray);

			$this->session->set_flashdata('msg','Accout Created Successfully');
			redirect(base_url().'index.php/Auth/guestRegister');
		}
	}

	public function transactionRegister()
	{
		$this->load->library('form_validation');

		// $this->form_validation->set_message('is_unique','Phone number already exits,pls enter another!');

		$this->form_validation->set_rules('uploaded_by','Uploaded By','required');
		$this->form_validation->set_rules('date_of_payment','Date of Payment','required');
		$this->form_validation->set_rules('gross_amount','Gross Amount','required');
		$this->form_validation->set_rules('taxable_amount','Taxable Amount','required');
		$this->form_validation->set_rules('gst_taxable_amount','GST Taxable Amount','required');

		if($this->form_validation->run() == false)
		{
			$this->load->view('transaction');
		}
		else
		{
			$this->load->model('Auth_model');
			$formArray=array();
			$formArray['uploaded_by']=$this->input->post('uploaded_by');
			$formArray['date_of_payment']=$this->input->post('date_of_payment');
			$formArray['gross_amount']=$this->input->post('gross_amount');
			$formArray['taxable_amount']=$this->input->post('taxable_amount');
			$formArray['gst_taxable_amount']=$this->input->post('gst_taxable_amount');

			$this->Auth_model->transactionCreate($formArray);

			$this->session->set_flashdata('msg','Accout Created Successfully');
			redirect(base_url().'index.php/Auth/transactionRegister');
		}
	}

	public function budgetRegister()
	{
		$this->load->library('form_validation');

		// $this->form_validation->set_message('is_unique','Phone number already exits,pls enter another!');

		$this->form_validation->set_rules('uploaded_by','Uploaded By','required');
		$this->form_validation->set_rules('fund_type','Fund Type','required');
		$this->form_validation->set_rules('head','Head','required');
		$this->form_validation->set_rules('remark','Remark');
		$this->form_validation->set_rules('purpose_for_fund','Purpose For Fund','required');

		if($this->form_validation->run() == false)
		{
			$this->load->view('budget');
		}
		else
		{
			$this->load->model('Auth_model');
			$formArray=array();
			$formArray['uploaded_by']=$this->input->post('uploaded_by');
			$formArray['fund_type']=$this->input->post('fund_type');
			$formArray['head']=$this->input->post('head');
			$formArray['remark']=$this->input->post('remark');
			$formArray['purpose_for_fund']=$this->input->post('purpose_for_fund');

			$this->Auth_model->budgetCreate($formArray);

			$this->session->set_flashdata('msg','Accout Created Successfully');
			redirect(base_url().'index.php/Auth/budgetRegister');
		}
	}
}